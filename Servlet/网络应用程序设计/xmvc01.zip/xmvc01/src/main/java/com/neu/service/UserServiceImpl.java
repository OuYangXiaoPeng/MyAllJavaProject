package com.neu.service;

import com.neu.mapper.UserMapper;
import com.neu.pojo.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;

    public User getUser(String userName) {
        return userMapper.findUserByName(userName);
    }

    /**
     * 登录验证方法的实现
     */
    public boolean isLogin(User user) {

        // 根据用户名从数据库中查找用户信息
        User dbUser = userMapper.findUserByName(user.getUserName());
        // 如果找到了用户并且密码正确，则返回 true
        if (dbUser != null && dbUser.getPassword().equals(user.getPassword())) {
            return true;
        }
        // 否则返回 false
        return false;
    }

    public List<User> getUsers() {

        return userMapper.findAll();
    }

}
