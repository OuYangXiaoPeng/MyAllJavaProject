package com.neu.controller;

import com.neu.pojo.User;
import com.neu.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * 用户管理Controller
 *
 * @author Admin
 */
@Controller
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;

    @RequestMapping("/index")
    public ModelAndView index(HttpServletRequest request) {

        // 从 session 中获取用户名
        String userName = (String) request.getSession().getAttribute("user");
        // 如果未登录，跳转到登录页面
        if (userName == null || "".equals(userName)) {
            return new ModelAndView("redirect:/index");
        }
        // 调用用户服务的查询方法
        List<User> userList = userService.getUsers();
        // 创建 ModelAndView 对象并设置返回视图名和数据模型
        ModelAndView mav = new ModelAndView("users");
        mav.addObject("userList", userList);
        // 返回 ModelAndView 对象
        return mav;
    }
}
